



//: Playground - noun: a place where people can play

import Foundation

class Singelton {
    private init() {
        print("Once")
    }
    
    static var sharedPreferance = Singelton()
    
}

Singelton.sharedPreferance
Singelton.sharedPreferance
Singelton.sharedPreferance


func multiply(a: Int, b: Int) -> Int {
    return a *  b
}

var myClosure = multiply
myClosure(2, 3)


func add(a: Int, b: Int) -> Int {
    return a + b
}

var addClosure = add
addClosure(5, 5)

var noParmeterNoReturnClosure: () -> Void = {
    print("no parameter no return type")
}
noParmeterNoReturnClosure()

var singleParameterNoReturn:(String) -> Void = {
    (type: String) in
    print(type)
}

singleParameterNoReturn("Swift")


var multipleParameterWithReturn = {
    (type1: String, type2: String)
    in
    return (type1 + type2)
}

multipleParameterWithReturn("Bill", " Gates")


var multiplyClosure = {
    (type: Int, type1: Int)
    in
    return type * type1
}
multiply(a: 2, b: 4)

var addition = {
    (type: Int, type1: Int)
    in
    return type + type1
}

var devide = {
    (a: Int, b: Int)
    in
    return a / b
}

func onOperation(a: Int, b: Int, operation:(Int, Int) -> Int) -> Int {
    operation(a,b)
    return a
}
onOperation(a: 4, b: 5, operation: multiplyClosure)

onOperation(a: 10, b: 20, operation: addition)

onOperation(a: 16, b: 8, operation: devide)

onOperation(a: 10, b: 20, operation: {(a: Int, b: Int) in return a - b})

onOperation(a: 5, b: 4, operation: {return $0 * $1})

onOperation(a: 6, b: 3, operation: *)

onOperation(a: 5, b: 4) {
    return $0 * $1
}

var a = [2,5,8]
for odd in a {
    if odd % 2 == 0  {
        print("even")
    }
    else {
        print("odd")
    }
}



var oddevenClosure:([Int]) -> (even:[Int], odd:[Int])  = {
    (array: [Int])
    in
    var oddArray = [Int]()
    var evenArray = [Int]()
    
    for item in array {
        if item % 2 == 0 {
            evenArray.append(item)
        }
        else {
            oddArray.append(item)
        }
    }
    
    return (oddArray,evenArray)
}

var anArray = [1,2,3,4,5,6,7]

oddevenClosure(anArray)
oddevenClosure(anArray).even
oddevenClosure(anArray).odd


var number = 7

var aclosure = {
    
    number += 1
    print(number)
}

aclosure()
aclosure()
aclosure()
aclosure()

func numberIncrement() {
    number += 1
}
numberIncrement()
numberIncrement()
numberIncrement()


var aArray = [12,20,30,45,54]

aArray.sorted { (a:Int, b:Int) -> Bool in
    return a > b
}
aArray.sort(by: >)
aArray.sort(by: <)






